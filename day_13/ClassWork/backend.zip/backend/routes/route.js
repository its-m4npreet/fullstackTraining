const route ={
    show:"/",
    create:"/create",
    deleteRoute:"/delete",
    update:"/update"
};

module.exports= route;
