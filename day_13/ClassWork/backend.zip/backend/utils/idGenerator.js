function IdGenerator(){
    // console.log(Math.abs(Math.round(Math.random()*10000)));
    
    return (Math.abs(Math.round(Math.random()*10000)))
}

module.exports=IdGenerator;

