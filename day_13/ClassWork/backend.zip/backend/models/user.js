const user={
    id:0,
    name:"",
    course:"",
    rollNumber:0
}

module.exports=user;